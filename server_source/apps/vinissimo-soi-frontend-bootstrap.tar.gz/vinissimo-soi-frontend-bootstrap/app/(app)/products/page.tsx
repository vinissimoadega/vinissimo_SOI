import { PageTemplate } from "@/components/page-template";

const rows = [
  {
    "sku": "VIN001",
    "produto": "Malbec Reserva 750ml",
    "categoria": "Tinto",
    "custo": "R$ 45,00",
    "status": "Ativo"
  },
  {
    "sku": "VIN002",
    "produto": "Espumante Brut 750ml",
    "categoria": "Espumante",
    "custo": "R$ 38,00",
    "status": "Ativo"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Produtos"
      description="Cadastro-mãe dos SKUs da Viníssimo."
      ctaLabel="Novo produto"
      columns={[
        { key: "sku", label: "SKU" },
        { key: "produto", label: "Produto" },
        { key: "categoria", label: "Categoria" },
        { key: "custo", label: "Custo base" },
        { key: "status", label: "Status" },
      ]}
      rows={rows}
    />
  );
}
