import { PageTemplate } from "@/components/page-template";
import { StatusBadge } from "@/components/status-badge";

const rows = [
  {
    "sku": "VIN001",
    "produto": "Malbec Reserva 750ml",
    "estoque": "—",
    "minimo": "—",
    "status": "atencao"
  },
  {
    "sku": "VIN002",
    "produto": "Espumante Brut 750ml",
    "estoque": "—",
    "minimo": "—",
    "status": "ok"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Estoque"
      description="Semáforos, cobertura, compra sugerida e capital empatado."
      ctaLabel="Ajuste manual"
      columns={[
        { key: "sku", label: "SKU" },
        { key: "produto", label: "Produto" },
        { key: "estoque", label: "Estoque" },
        { key: "minimo", label: "Mínimo usado" },
        { key: "status", label: "Status", render: (row) => <StatusBadge label={String(row.status).replace("_", " ")} tone={row.status as "ruptura" | "repor_agora" | "atencao" | "ok"} /> },
      ]}
      rows={rows}
    />
  );
}
