import { PageTemplate } from "@/components/page-template";
import { StatusBadge } from "@/components/status-badge";

const rows = [
  {
    "nome": "Cliente Exemplo 1",
    "telefone": "(62) 99999-0001",
    "origem": "WhatsApp",
    "ultima": "—",
    "status": "lead"
  },
  {
    "nome": "Cliente Exemplo 2",
    "telefone": "(62) 99999-0002",
    "origem": "Instagram",
    "ultima": "—",
    "status": "inativo"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Clientes"
      description="Base de CRM operacional com status e histórico."
      ctaLabel="Novo cliente"
      columns={[
        { key: "nome", label: "Nome" },
        { key: "telefone", label: "Telefone" },
        { key: "origem", label: "Origem" },
        { key: "ultima", label: "Última compra" },
        { key: "status", label: "Status", render: (row) => <StatusBadge label={String(row.status)} tone={row.status as "lead" | "novo" | "recorrente" | "inativo"} /> },
      ]}
      rows={rows}
    />
  );
}
