import { AlertsList } from "@/components/alerts-list";
import { KpiCard } from "@/components/kpi-card";
import { QuickActions } from "@/components/quick-actions";
import { SectionCard } from "@/components/section-card";
import { SimpleTable } from "@/components/simple-table";
import { StatusBadge } from "@/components/status-badge";
import { getDashboardBootstrapData } from "@/lib/api";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const data = await getDashboardBootstrapData();

  const bootstrapStatus = data.health ? "Conectado" : "Fallback";
  const bootstrapTone = data.health ? "success" : "warning";

  return (
    <div className="page-shell">
      <header className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p className="mt-2 text-sm text-black/55">
            Visão executiva inicial do SOI, alinhada ao wireframe funcional e já
            conectada ao backend mínimo da Viníssimo.
          </p>
        </div>
        <div className="page-header-actions">
          <button className="btn-secondary">Exportar leitura</button>
          <button className="btn-primary">Nova venda</button>
        </div>
      </header>

      <SectionCard
        title="Bootstrap do sistema"
        subtitle="Estado atual da API e da configuração corrente do SOI."
      >
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="surface-muted p-4">
            <p className="text-sm text-black/55">API</p>
            <div className="mt-3 flex items-center gap-2">
              <StatusBadge label={bootstrapStatus} tone={bootstrapTone} />
              <p className="text-sm text-black/45">
                {data.health
                  ? `${data.health.database.current_database} / ${data.health.database.current_user}`
                  : "Sem resposta do backend; usando fallback visual."}
              </p>
            </div>
          </div>

          <div className="surface-muted p-4">
            <p className="text-sm text-black/55">Margem mínima</p>
            <p className="mt-3 text-2xl font-semibold text-grafite">
              {data.settings
                ? `${(Number(data.settings.margin_min_target) * 100).toFixed(0)}%`
                : "—"}
            </p>
          </div>

          <div className="surface-muted p-4">
            <p className="text-sm text-black/55">Lead time / segurança</p>
            <p className="mt-3 text-2xl font-semibold text-grafite">
              {data.settings
                ? `${data.settings.replenishment_lead_time_days}d + ${data.settings.stock_safety_days}d`
                : "—"}
            </p>
          </div>
        </div>
      </SectionCard>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {data.kpis.map((item) => (
          <KpiCard
            key={item.label}
            label={item.label}
            value={item.value}
            helper={item.helper}
            tone={item.tone}
          />
        ))}
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <SectionCard
          title="Alertas críticos"
          subtitle="O dashboard deve mostrar cedo o que exige ação."
        >
          <AlertsList items={data.alerts} />
        </SectionCard>

        <SectionCard
          title="Ações rápidas"
          subtitle="Fluxo diário encurtado para operação."
        >
          <QuickActions />
        </SectionCard>
      </div>

      <SectionCard
        title="Performance por canal"
        subtitle="Estrutura inicial da leitura econômica por origem de venda."
      >
        <SimpleTable
          columns={[
            { key: "channel", label: "Canal" },
            { key: "pedidos", label: "Pedidos" },
            { key: "receita", label: "Receita líquida" },
            { key: "lucro", label: "Lucro bruto" },
            { key: "ticket", label: "Ticket médio" },
            { key: "margem", label: "Margem média" }
          ]}
          rows={data.channelPerformance}
        />
      </SectionCard>

      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard
          title="Estoque crítico"
          subtitle="Lista inicial priorizando o que precisa de leitura operacional."
        >
          <SimpleTable
            columns={[
              { key: "sku", label: "SKU" },
              { key: "produto", label: "Produto" },
              { key: "estoque", label: "Estoque" },
              { key: "minimo", label: "Mínimo" },
              { key: "cobertura", label: "Cobertura" },
              {
                key: "status",
                label: "Status",
                render: (row) => (
                  <StatusBadge
                    label={String(row.status).replace("_", " ")}
                    tone={row.status as "ruptura" | "repor_agora" | "atencao" | "ok"}
                  />
                )
              }
            ]}
            rows={data.stockCritical}
          />
        </SectionCard>

        <SectionCard
          title="Clientes em atenção"
          subtitle="Estrutura inicial da leitura de CRM operacional."
        >
          <SimpleTable
            columns={[
              { key: "nome", label: "Cliente" },
              {
                key: "status",
                label: "Status",
                render: (row) => (
                  <StatusBadge
                    label={String(row.status)}
                    tone={row.status as "lead" | "novo" | "recorrente" | "inativo"}
                  />
                )
              },
              { key: "ultimaCompra", label: "Última compra" },
              { key: "ticket", label: "Ticket médio" }
            ]}
            rows={data.customerAttention}
          />
        </SectionCard>
      </div>
    </div>
  );
}
