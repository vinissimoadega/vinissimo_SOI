import { PageTemplate } from "@/components/page-template";

const rows = [
  {
    "numero": "VEN-0001",
    "data": "01/04/2026",
    "cliente": "Cliente Exemplo 1",
    "canal": "WhatsApp",
    "receita": "R$ 0,00",
    "lucro": "R$ 0,00"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Vendas"
      description="Pedidos, margem e baixa de estoque por canal."
      ctaLabel="Nova venda"
      columns={[
        { key: "numero", label: "Nº venda" },
        { key: "data", label: "Data" },
        { key: "cliente", label: "Cliente" },
        { key: "canal", label: "Canal" },
        { key: "receita", label: "Receita líquida" },
        { key: "lucro", label: "Lucro" },
      ]}
      rows={rows}
    />
  );
}
