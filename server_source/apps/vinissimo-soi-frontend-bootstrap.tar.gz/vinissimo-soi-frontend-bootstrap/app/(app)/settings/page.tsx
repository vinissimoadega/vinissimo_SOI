import { PageTemplate } from "@/components/page-template";

const rows = [
  {
    "parametro": "Margem mínima",
    "valor": "35%"
  },
  {
    "parametro": "Lead time",
    "valor": "7 dias"
  },
  {
    "parametro": "Estoque de segurança",
    "valor": "5 dias"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Configurações"
      description="Parâmetros correntes que sustentam o cálculo operacional do SOI."
      ctaLabel="Salvar alterações"
      filters={
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          <input className="input-soft" placeholder="Margem mínima" defaultValue="35%" />
          <input className="input-soft" placeholder="Lead time" defaultValue="7 dias" />
          <input className="input-soft" placeholder="Segurança" defaultValue="5 dias" />
          <input className="input-soft" placeholder="Cliente inativo" defaultValue="45 dias" />
          <select className="input-soft">
            <option>Taxa iFood 18%</option>
          </select>
        </div>
      }
      columns={[
        { key: "parametro", label: "Parâmetro" },
        { key: "valor", label: "Valor" },
      ]}
      rows={rows}
    />
  );
}
