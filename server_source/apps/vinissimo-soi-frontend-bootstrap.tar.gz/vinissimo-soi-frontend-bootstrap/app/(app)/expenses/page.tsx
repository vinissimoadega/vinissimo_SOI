import { PageTemplate } from "@/components/page-template";

const rows = [
  {
    "data": "01/04/2026",
    "tipo": "Marketing",
    "canal": "Geral",
    "valor": "R$ 0,00",
    "natureza": "Fixa"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Despesas"
      description="Leitura de custo fixo e variável da operação."
      ctaLabel="Nova despesa"
      columns={[
        { key: "data", label: "Data" },
        { key: "tipo", label: "Tipo" },
        { key: "canal", label: "Canal" },
        { key: "valor", label: "Valor" },
        { key: "natureza", label: "Natureza" },
      ]}
      rows={rows}
    />
  );
}
