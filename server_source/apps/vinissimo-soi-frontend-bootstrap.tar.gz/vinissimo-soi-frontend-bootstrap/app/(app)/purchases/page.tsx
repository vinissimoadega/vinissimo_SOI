import { PageTemplate } from "@/components/page-template";

const rows = [
  {
    "numero": "CMP-0001",
    "data": "01/04/2026",
    "fornecedor": "Fornecedor A",
    "itens": "2",
    "total": "R$ 0,00"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Compras"
      description="Entradas de estoque e custo real por item."
      ctaLabel="Nova compra"
      columns={[
        { key: "numero", label: "Nº compra" },
        { key: "data", label: "Data" },
        { key: "fornecedor", label: "Fornecedor" },
        { key: "itens", label: "Itens" },
        { key: "total", label: "Total" },
      ]}
      rows={rows}
    />
  );
}
