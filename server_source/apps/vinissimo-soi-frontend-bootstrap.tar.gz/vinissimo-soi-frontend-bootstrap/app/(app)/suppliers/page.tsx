import { PageTemplate } from "@/components/page-template";

const rows = [
  {
    "nome": "Fornecedor A",
    "contato": "Comercial A",
    "telefone": "(62) 99999-0001",
    "lead": "7 dias",
    "status": "Ativo"
  },
  {
    "nome": "Fornecedor B",
    "contato": "Comercial B",
    "telefone": "(62) 99999-0002",
    "lead": "5 dias",
    "status": "Ativo"
  }
];

export default function Page() {
  return (
    <PageTemplate
      title="Fornecedores"
      description="Cadastro e leitura de lead time dos fornecedores."
      ctaLabel="Novo fornecedor"
      columns={[
        { key: "nome", label: "Nome" },
        { key: "contato", label: "Contato" },
        { key: "telefone", label: "Telefone" },
        { key: "lead", label: "Lead time" },
        { key: "status", label: "Status" },
      ]}
      rows={rows}
    />
  );
}
