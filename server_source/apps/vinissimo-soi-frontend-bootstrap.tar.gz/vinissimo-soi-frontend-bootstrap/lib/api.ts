import type { CurrentSettings, HealthResponse } from "@/types";
import {
  fallbackAlerts,
  fallbackChannelPerformance,
  fallbackCustomerAttention,
  fallbackKpis,
  fallbackStockCritical,
} from "./mock";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL || "http://127.0.0.1:4100/api/v1";

async function safeFetch<T>(path: string): Promise<T | null> {
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      cache: "no-store",
    });

    if (!response.ok) return null;
    return (await response.json()) as T;
  } catch {
    return null;
  }
}

export async function getHealth(): Promise<HealthResponse | null> {
  return safeFetch<HealthResponse>("/health");
}

export async function getCurrentSettings(): Promise<CurrentSettings | null> {
  return safeFetch<CurrentSettings>("/settings/current");
}

export async function getDashboardBootstrapData() {
  const [health, settings] = await Promise.all([
    getHealth(),
    getCurrentSettings(),
  ]);

  return {
    health,
    settings,
    kpis: fallbackKpis,
    alerts: fallbackAlerts,
    channelPerformance: fallbackChannelPerformance,
    stockCritical: fallbackStockCritical,
    customerAttention: fallbackCustomerAttention,
  };
}
