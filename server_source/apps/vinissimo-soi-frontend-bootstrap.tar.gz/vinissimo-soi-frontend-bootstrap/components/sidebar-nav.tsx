"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { navigation } from "@/lib/navigation";
import { cn } from "./utils";

export function SidebarNav() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-72 shrink-0 border-r border-black/5 bg-vinho-950 text-white lg:flex lg:flex-col">
      <div className="border-b border-white/10 px-6 py-6">
        <p className="text-xs uppercase tracking-[0.24em] text-white/50">
          Viníssimo
        </p>
        <h2 className="mt-2 text-xl font-semibold text-white">SOI</h2>
        <p className="mt-2 text-sm text-white/65">
          Sistema Operacional Inteligente
        </p>
      </div>

      <nav className="flex-1 space-y-1 p-4">
        {navigation.map((item) => {
          const Icon = item.icon;
          const active =
            pathname === item.href || pathname.startsWith(`${item.href}/`);

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition",
                active
                  ? "bg-white/10 text-white"
                  : "text-white/70 hover:bg-white/5 hover:text-white",
              )}
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-white/10 p-4 text-xs text-white/45">
        Ambiente local / bootstrap inicial
      </div>
    </aside>
  );
}
