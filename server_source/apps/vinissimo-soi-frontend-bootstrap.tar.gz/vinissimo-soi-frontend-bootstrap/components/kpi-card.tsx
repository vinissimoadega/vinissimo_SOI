import { cn } from "./utils";

type Tone = "default" | "danger" | "success" | "warning";

const toneClasses: Record<Tone, string> = {
  default: "bg-white",
  danger: "bg-red-50",
  success: "bg-emerald-50",
  warning: "bg-amber-50",
};

export function KpiCard({
  label,
  value,
  helper,
  tone = "default",
}: {
  label: string;
  value: string;
  helper?: string;
  tone?: Tone;
}) {
  return (
    <article className={cn("surface p-4", toneClasses[tone])}>
      <p className="text-sm text-black/55">{label}</p>
      <p className="mt-3 text-2xl font-semibold tracking-tight text-grafite">
        {value}
      </p>
      {helper ? <p className="mt-2 text-xs text-black/45">{helper}</p> : null}
    </article>
  );
}
