import { cn } from "./utils";

export type SimpleTableColumn<T> = {
  key: keyof T | string;
  label: string;
  render?: (row: T) => React.ReactNode;
  className?: string;
};

export function SimpleTable<T extends Record<string, unknown>>({
  columns,
  rows,
  emptyMessage = "Nenhum registro encontrado.",
}: {
  columns: SimpleTableColumn<T>[];
  rows: T[];
  emptyMessage?: string;
}) {
  return (
    <div className="table-shell">
      <table className="min-w-full">
        <thead className="table-head">
          <tr>
            {columns.map((column) => (
              <th key={column.label} className="px-4 py-3">
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td className="table-cell text-black/45" colSpan={columns.length}>
                {emptyMessage}
              </td>
            </tr>
          ) : (
            rows.map((row, index) => (
              <tr key={index}>
                {columns.map((column) => (
                  <td key={column.label} className={cn("table-cell", column.className)}>
                    {column.render
                      ? column.render(row)
                      : String(row[column.key as keyof T] ?? "—")}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
