import { CalendarDays, Search, UserCircle2 } from "lucide-react";

export function Topbar() {
  return (
    <header className="sticky top-0 z-20 border-b border-black/5 bg-[#fbf8f5]/95 backdrop-blur">
      <div className="flex items-center justify-between gap-4 px-4 py-3 lg:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <div className="rounded-xl bg-vinho-900 px-3 py-2 text-sm font-semibold text-white lg:hidden">
            SOI
          </div>
          <div className="relative hidden min-w-[260px] sm:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/35" />
            <input
              className="input-soft w-full pl-9"
              placeholder="Buscar cliente, SKU, pedido ou alerta"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="btn-secondary gap-2">
            <CalendarDays className="h-4 w-4" />
            Mês atual
          </button>
          <button className="btn-secondary gap-2">
            <UserCircle2 className="h-4 w-4" />
            Operação
          </button>
        </div>
      </div>
    </header>
  );
}
