import { SectionCard } from "./section-card";
import { SimpleTable, type SimpleTableColumn } from "./simple-table";

export function PageTemplate<T extends Record<string, unknown>>({
  title,
  description,
  ctaLabel,
  filters,
  columns,
  rows,
}: {
  title: string;
  description: string;
  ctaLabel: string;
  filters?: React.ReactNode;
  columns: SimpleTableColumn<T>[];
  rows: T[];
}) {
  return (
    <div className="page-shell">
      <header className="page-header">
        <div>
          <h1>{title}</h1>
          <p className="mt-2 text-sm text-black/55">{description}</p>
        </div>
        <div className="page-header-actions">
          <button className="btn-primary">{ctaLabel}</button>
        </div>
      </header>

      <SectionCard
        title="Filtros"
        subtitle="Estrutura inicial alinhada ao wireframe funcional do SOI."
      >
        {filters ?? (
          <div className="grid gap-3 md:grid-cols-3">
            <input className="input-soft" placeholder="Busca" />
            <select className="input-soft">
              <option>Status</option>
            </select>
            <select className="input-soft">
              <option>Categoria / Origem</option>
            </select>
          </div>
        )}
      </SectionCard>

      <SectionCard title="Lista" subtitle="Tabela-base para o módulo.">
        <SimpleTable columns={columns} rows={rows} />
      </SectionCard>
    </div>
  );
}
