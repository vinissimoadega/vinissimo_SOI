export type HealthResponse = {
  status: string;
  service: string;
  timestamp: string;
  database: {
    current_database: string;
    current_user: string;
  };
};

export type CurrentSettings = {
  id: string;
  margin_min_target: string;
  replenishment_lead_time_days: number;
  stock_safety_days: number;
  customer_inactive_days: number;
  fee_whatsapp: string;
  fee_instagram: string;
  fee_ifood: string;
  fee_counter: string;
  fixed_monthly_expense_estimate: string;
  avg_packaging_unit_cost: string;
  effective_from: string;
  is_current: boolean;
  created_at: string;
  created_by: string | null;
};

export type KpiCardData = {
  label: string;
  value: string;
  tone?: "default" | "danger" | "success" | "warning";
  helper?: string;
};

export type AlertItem = {
  id: string;
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  message: string;
  entity: string;
  href: string;
};

export type ChannelPerformance = {
  channel: string;
  pedidos: number;
  receita: string;
  lucro: string;
  ticket: string;
  margem: string;
};

export type StockCriticalItem = {
  sku: string;
  produto: string;
  estoque: string;
  minimo: string;
  cobertura: string;
  status: "ruptura" | "repor_agora" | "atencao" | "ok";
};

export type CustomerAttentionItem = {
  nome: string;
  status: "lead" | "novo" | "recorrente" | "inativo";
  ultimaCompra: string;
  ticket: string;
};
